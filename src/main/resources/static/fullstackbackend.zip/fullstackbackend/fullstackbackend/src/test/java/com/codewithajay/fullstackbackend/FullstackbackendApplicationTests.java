package com.codewithajay.fullstackbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullstackbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
