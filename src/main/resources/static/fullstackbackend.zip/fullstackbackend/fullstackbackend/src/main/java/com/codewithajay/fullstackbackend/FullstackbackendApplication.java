package com.codewithajay.fullstackbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FullstackbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FullstackbackendApplication.class, args);
	}

}
